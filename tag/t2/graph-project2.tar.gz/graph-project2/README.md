compile with g++ -std=c++11 proj2.cpp -o a
execute with ./a

authors : Gabriel Levi - 16/0006490 Léo Moraes - 16/0011795 
